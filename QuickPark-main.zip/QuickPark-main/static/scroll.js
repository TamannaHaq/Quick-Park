$(document).ready(function (){
    $('#btn').click(function(){
        $("html,body").animate({ scrollTop: 0 }, "slow");
        
    })
   
})
