from django.contrib import admin

from .models import *


admin.site.register(Area)
admin.site.register(Slots)
admin.site.register(Booking)
admin.site.register(Config)